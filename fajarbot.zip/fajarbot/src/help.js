const help = (prefix) => {
	return `
	Anak Kontol sksk, manunya kek gimana
`
}

exports.help = help
